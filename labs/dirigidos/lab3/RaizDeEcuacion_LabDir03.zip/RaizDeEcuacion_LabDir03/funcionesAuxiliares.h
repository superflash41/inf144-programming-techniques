/*
 * Proyecto:  RaizDeEcuacion 
 * Archivo:   funcionesAuxiliares.cpp
 * Autor:     Ana Cecilia Roncal Neyra
 * Fecha:     Marzo del 2023
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

double calcularFx(double ,double ,double ,double ,double, double);
double calcularPotencia(double, int);
void solucionarProblema(double, double, double, double, double, double, double, 
                        double, double, double);

#endif /* FUNCIONESAUXILIARES_H */

