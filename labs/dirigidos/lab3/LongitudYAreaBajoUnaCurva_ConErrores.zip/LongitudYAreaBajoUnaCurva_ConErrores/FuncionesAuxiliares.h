/* 
 * Proyecto: LongitudYAreaBajoUnaCurva
 * Archivo:  FuncionesAuxiliares.h
 * Autor:    J. miguel.guanira.
 *
 * Created on 24 de agosto de 2022, 11:44 AM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

double evaluaLaFuncion(double, double, double, double, double, double, double);
double potencia(double, int);

#endif /* FUNCIONESAUXILIARES_H */

